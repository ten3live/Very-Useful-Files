# How-to-Mock-API-In-React
This application does a simple crud operation by Mocking the API using axios-mock-adapter
