import mock from './mock'
import './employee'

mock.onAny().passThrough()